from django.urls import path
from LastName import views 

urlpatterns =[
    path('lastname/', views.lastname),
 
]