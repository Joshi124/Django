from django.apps import AppConfig


class HetalappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hetalapp'
